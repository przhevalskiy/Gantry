(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,n=`feedkill_state_v1`,r={youtube:!0,instagram:!0,x:!0,redirectShorts:!0};function i(){return{version:1,settings:{...r}}}async function a(){let e=(await t.storage.local.get(n))[n];return e?.version===1?{version:1,settings:{...r,...e.settings}}:i()}function o(e){let t=e.toLowerCase();return t.includes(`youtube.com`)?`youtube`:t.includes(`instagram.com`)?`instagram`:t===`x.com`||t.endsWith(`.x.com`)||t.includes(`twitter.com`)?`x`:null}var s={youtube:`
ytd-rich-shelf-renderer:has(a[href*="/shorts/"]),
ytd-reel-shelf-renderer,
ytd-mini-guide-entry-renderer:has(a[title="Shorts"]),
ytd-guide-entry-renderer:has(a[title="Shorts"]),
ytd-guide-entry-renderer:has(a[href*="/shorts"]),
ytm-pivot-bar-item-renderer:has(a[href*="/shorts"]),
ytd-video-renderer:has(a[href*="/shorts/"]),
ytd-grid-video-renderer:has(a[href*="/shorts/"]),
ytd-rich-item-renderer:has(a[href*="/shorts/"]),
ytd-reel-item-renderer,
[is-shorts],
ytd-thumbnail-overlay-time-status-renderer[overlay-style="SHORTS"] {
  display: none !important;
}
`,instagram:`
a[href="/reels/"],
a[href*="/reels/"],
div:has(> a[href="/reels/"]),
[role="menuitem"]:has(a[href*="/reels"]),
section:has(a[href*="/reels/"]) svg[aria-label="Reels"] {
  /* structural hooks vary; JS also marks data-feedkill */
}
[data-feedkill="hide"] {
  display: none !important;
}
`,x:`
[data-testid="primaryColumn"] a[href="/home"] ~ div,
a[href="/i/grok"],
[data-testid="sidebarColumn"] {
  /* keep structure; JS marks For You tab + explore distractors */
}
[data-feedkill="hide"] {
  display: none !important;
}
`};function c(e){return e.match(/^\/shorts\/([A-Za-z0-9_-]+)/)?.[1]??null}var l=e({matches:[`https://www.youtube.com/*`,`https://m.youtube.com/*`,`https://www.instagram.com/*`,`https://instagram.com/*`,`https://x.com/*`,`https://twitter.com/*`],runAt:`document_start`,async main(){let e=o(location.hostname);if(!e)return;let n=(await a()).settings,r=document.createElement(`style`);r.id=`feedkill-style`,(document.documentElement||document).appendChild(r);let i=t=>{r.textContent=t[e]?s[e]:``};i(n);let l=()=>{if(!n.redirectShorts||e!==`youtube`||!n.youtube)return;let t=c(location.pathname);t&&location.replace(`https://www.youtube.com/watch?v=${t}`)};l();let u=()=>{e===`instagram`&&n.instagram&&(document.querySelectorAll(`a[href="/reels/"], a[href*="/reels/"]`).forEach(e=>{let t=e.closest(`div[role="menuitem"], a, div`);t&&t.setAttribute(`data-feedkill`,`hide`)}),document.querySelectorAll(`a[href="/explore/"]`).forEach(e=>{}),location.pathname.startsWith(`/reels`)&&(history.replaceState(null,``,`/`),location.reload()))},d=()=>{if(e===`x`&&n.x&&(document.querySelectorAll(`[role="tab"]`).forEach(e=>{let t=(e.textContent||``).trim().toLowerCase();(t===`for you`||t===`para ti`)&&e.setAttribute(`data-feedkill`,`hide`)}),location.pathname===`/home`)){let e=[...document.querySelectorAll(`[role="tab"]`)].find(e=>/^(following|siguiendo)$/i.test((e.textContent||``).trim()));e&&e.getAttribute(`aria-selected`)!==`true`&&e.click()}},f=()=>{u(),d(),l()};f(),new MutationObserver(()=>f()).observe(document.documentElement,{childList:!0,subtree:!0}),t.storage.onChanged.addListener((e,t)=>{if(t!==`local`||!e.feedkill_state_v1)return;let r=e.feedkill_state_v1.newValue;r?.settings&&(n=r.settings,i(n),f())}),document.addEventListener(`yt-navigate-finish`,()=>{l(),f()})}}),u={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},d=class e extends Event{static EVENT_NAME=f(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function f(e){return`${t?.runtime?.id}:content:${e}`}var p=typeof globalThis.navigation?.addEventListener==`function`;function m(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),p?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new d(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new d(e,t)),t=e)},1e3))}}}var h=class e{static SCRIPT_STARTED_MESSAGE_TYPE=f(`wxt:content-script-started`);id;abortController;locationWatcher=m(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return t.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?f(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),u.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},g={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=l;return await e(new h(`content`,t))}catch(e){throw g.error(`The content script "content" crashed on startup!`,e),e}})()})();